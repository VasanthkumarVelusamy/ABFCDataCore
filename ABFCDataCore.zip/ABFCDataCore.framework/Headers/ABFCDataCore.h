//
//  ABFCDataCore.h
//  ABFCDataCore
//
//  Created by 1741103 on 10/08/19.
//  Copyright © 2019 1741103. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ABFCDataCore.
FOUNDATION_EXPORT double ABFCDataCoreVersionNumber;

//! Project version string for ABFCDataCore.
FOUNDATION_EXPORT const unsigned char ABFCDataCoreVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ABFCDataCore/PublicHeader.h>


